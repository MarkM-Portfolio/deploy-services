#!/bin/bash

function usage() {
    echo "Usage: enableAntivirus.sh true|false"
}

# Validate command options
enableAntivirus="$1"
if [[ ( "$#" -ne 1 ) || (( "$1" != "true" ) && ( "$1" != "false" )) ]]; then
    usage
    exit 1
fi

# Check if antivirus is installed
if [ ! -e "/opt/Symantec/symantec_antivirus/sav" ]; then
    exit 0
fi

# Stop antivirus
if [ "${enableAntivirus}" == "true" ]; then
    echo "Enabling antivirus..."
    /opt/Symantec/symantec_antivirus/sav autoprotect -e
else
    echo "Disabling antivirus..."
    /opt/Symantec/symantec_antivirus/sav autoprotect -d
fi

# Print antivirus status
avStatus=$(/opt/Symantec/symantec_antivirus/sav info -a)
echo "Antivirus state: ${avStatus}"
exit 0

