import sys

execfile('clusterFuncs.py')

#
# Print the name of the server where the specified application is installed, based on whether the environment is
# split JVM or not (default=false).
#
# Usage: python getServerName.py <appName> <nodeName>
#
# 	<appName>	Name of the application
#	<nodeName>	Name of node to search for applications/servers
#

def main():

	if (len(sys.argv) < 2):
	    print ""
	    return 1 # fail
	#endif

	applicationName=sys.argv[0]
	nodeName = sys.argv[1]

	serverApplicationMap = getApplicationToServerMap(nodeName)
	if (serverApplicationMap == -1):
	    print ""
	    return 1 # fail
	#endif

	#
	# Print the name of the server on which the specified application is installed, or nothing if
	# aplicaiton name is not in the map
	#
	if serverApplicationMap.has_key(applicationName):
	    print "APPLICATION INSTALLED ON: " + serverApplicationMap[applicationName]
	    return 0 # success
	else:   
	    print ""
	    return 1 # fail
	#endif

#endDef


# Allow this file to be used as a module
if __name__ == "__main__":
	# Call the main function
	main()
#endif "__main__"

