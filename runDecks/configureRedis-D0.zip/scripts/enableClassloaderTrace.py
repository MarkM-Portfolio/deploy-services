# ***************************************************************** 
#                                                                   
# IBM Confidential                                                  
#                                                                   
# OCO Source Materials                                              
#                                                                   
# Copyright IBM Corp. 2014                                    
#                                                                   
# The source code for this program is not published or otherwise    
# divested of its trade secrets, irrespective of what has been      
# deposited with the U.S. Copyright Office.                         
#                                                                   
# ***************************************************************** 


execfile("/opt/ll/scripts/ac/wsadminlib.py")

from java.lang import String
traceSpec = 'com.ibm.ws.classloader.*=all=enabled'
nodes = AdminNodeManagement.listNodes()
for node in nodes:
        nodeStr = String(node)
        nodeStr = String(nodeStr.substring(0, nodeStr.indexOf('('))).trim()
        appServers = AdminServerManagement.listServers('APPLICATION_SERVER', nodeStr)
        for appServer in appServers:
                appServerStr = String(appServer)
                appServerStr = String(appServerStr.substring(0, appServerStr.indexOf('('))).trim()
                if appServerStr.lower() in ['servera','serverc','engage_server','servers'] :
                        AdminTask.setTraceSpecification('[-serverName ' + appServerStr +' -nodeName ' + nodeStr + ' -traceSpecification ' + traceSpec + ' -persist true]')

AdminConfig.save()
