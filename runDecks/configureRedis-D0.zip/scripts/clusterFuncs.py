#--------------------------------------------------------------------
# Set global constants
#--------------------------------------------------------------------

import sys
import java
import AdminUtilities 
import javax.management as mgmt


## Get a map of Application to server names (array) where the application is installed
def getApplicationToServerMap( nodeName, failonerror=AdminUtilities._BLANK_):
        if (failonerror==AdminUtilities._BLANK_): 
                failonerror=AdminUtilities._FAIL_ON_ERROR_
        #endIf
        msgPrefix = "getApplicationToServerMap("+`nodeName`+", "+`failonerror`+"): "

        try:
		# Initialize return value
		appToServerMap = {}

		# Get a  list of servers (config ids), and loop through determining which applications
		# are installed and build the map.
		servers = listServerIds("APPLICATION_SERVER", nodeName)
		for sid in servers:
		    serverName = sid[0:sid.find("(")]
		    apps = listApplicationsByTarget(nodeName, serverName)
		    for app in apps:
			# Make sure application is not intalled on multiple servers on this node...this is a limitation of the current patch scripts.
			# TODO: Remove this limitation
			if appToServerMap.has_key(app):
			    AdminUtilities.warningNotice(msgPrefix+"Application installed on multiple servers: "+app+" - ignoring on server"+serverName)
			    continue
			#endif
			
			# Add this app/serverName pair to the map
			appToServerMap[app] = serverName
		    #endFor
		#endFor

		return appToServerMap

        except:
                typ, val, tb = sys.exc_info()
                if (typ==SystemExit):  raise SystemExit,`val`
                if (failonerror != "true"):
                   print "Exception: %s %s " % (sys.exc_type, sys.exc_value)
                   val = "%s %s" % (sys.exc_type, sys.exc_value)
                   raise "ScriptLibraryException: ", `val`
                   return -1
                else:   
                   return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), failonerror)
                #endIf
        #endTry

        #return 1  # succeed
#endDef


## List applications by a specified target ##
def listApplicationsByTarget( nodeName, serverName, failonerror=AdminUtilities._BLANK_):
        if (failonerror==AdminUtilities._BLANK_): 
                failonerror=AdminUtilities._FAIL_ON_ERROR_
        #endIf
        msgPrefix = "listApplicationsByTarget("+`nodeName`+", "+`serverName`+", "+`failonerror`+"): "

        try:
                #--------------------------------------------------------------------
                # Set up globals
                #--------------------------------------------------------------------
                global AdminApp
                
                # Check the required parameters
                if (nodeName == ""):
                   raise AttributeError(AdminUtilities._formatNLS(resourceBundle, "WASL6041E", ["nodeName", nodeName]))

                if (serverName == ""):
                   raise AttributeError(AdminUtilities._formatNLS(resourceBundle, "WASL6041E", ["serverName", serverName]))

                # Check if node exists
                node = AdminConfig.getid("/Node:"+nodeName+"/")
                if (len(node) == 0):
                   raise AttributeError(AdminUtilities._formatNLS(resourceBundle, "WASL6040E", ["nodeName", nodeName]))
                #endIf
                
                # Check if server exists
                server = AdminConfig.getid("/Node:"+nodeName+"/Server:"+serverName)
                if (len(server) == 0):
                   raise AttributeError(AdminUtilities._formatNLS(resourceBundle, "WASL6040E", ["serverName", serverName]))
                #endIf
                
                cell = AdminConfig.list("Cell")
                cellName = AdminConfig.showAttribute(cell, "name")
                
                server = "WebSphere:cell="+cellName+",node="+nodeName+",server="+serverName
                
                # list applications that are deployed on serverName
                apps = AdminApp.list(server)
                AdminUtilities.infoNotice(apps)
                apps = AdminUtilities.convertToList(apps)
                return apps
        except:
                typ, val, tb = sys.exc_info()
                if (typ==SystemExit):  raise SystemExit,`val`
                if (failonerror != "true"):
                   print "Exception: %s %s " % (sys.exc_type, sys.exc_value)
                   val = "%s %s" % (sys.exc_type, sys.exc_value)
                   raise "ScriptLibraryException: ", `val`
                   return -1
                else:   
                   return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), failonerror)
                #endIf
                
        #endTry
        AdminUtilities.infoNotice(AdminUtilities._OK_+msgPrefix)
        #return 1  # succeed
#endDef


## List available servers with given server type and node ##
def listServerIds(serverType="", nodeName="", failonerror=AdminUtilities._BLANK_):
    if (failonerror==AdminUtilities._BLANK_): 
        failonerror=AdminUtilities._FAIL_ON_ERROR_
    #endIf
    msgPrefix = "listServers("+`serverType`+", "+`nodeName`+", "+`failonerror`+"): "

    try:
        # Construct optional parameters
        optionalParamList = []

        if (len(serverType) > 0):
            optionalParamList = ['-serverType', serverType] 

        if (len(nodeName) > 0):
            # check if node exists
            node = AdminConfig.getid("/Node:" +nodeName+"/")
            if (len(node) == 0):
               raise AttributeError(AdminUtilities._formatNLS(resourceBundle, "WASL6040E", ["nodeName", nodeName]))
            #endIf
            optionalParamList = optionalParamList + ['-nodeName', nodeName]
        #endIf

        # List servers with specified server type
        servers = AdminTask.listServers(optionalParamList)

        # Convert Jython string to list
        servers = AdminUtilities.convertToList(servers)

        # Loop through each server in server list
        newservers = []
        for aServer in servers:
            # Obtain server and node names
            sname = aServer[0:aServer.find("(")]
            nname = aServer[aServer.find("nodes/")+6:aServer.find("servers/")-1]
            # Retrieve the server config id
            sid = AdminConfig.getid("/Node:"+nname+"/Server:"+sname)
            if (newservers.count(sid) <= 0):
                  newservers.append(sid)
            #endif
        #endFor
        return newservers
    except:
        typ, val, tb = sys.exc_info()
        if (typ==SystemExit):  raise SystemExit,`val`
        if (failonerror != AdminUtilities._TRUE_):
            print "Exception: %s %s " % (sys.exc_type, sys.exc_value)
            val = "%s %s" % (sys.exc_type, sys.exc_value)
            raise "ScriptLibraryException: ", `val`
            return -1
        else:
            return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), failonerror)
        #endIf
    #endTry
    
#endDef


## Mark server up/down in cluster ##
def setClusterMemberAvailableById( sid, available="true", last="false" ):

	msgPrefix = "setClusterMemberAvailable("+sid+", "+available+", "+last+"): "

	try:
	    	# Parse out the server and node names from server id
	    	# sid format is: serverC(cells/ocs_cell/nodes/ocs_app_node_acdmgr/servers/serverC|server.xml#Server_1450317818808)
		# and get the cluster name
            	serverName = sid[0:sid.find("(")]
            	nodeName = sid[sid.find("nodes/")+6:sid.find("servers/")-1]
 		clusterName = AdminConfig.showAttribute(sid, "clusterName")

		# If server is not in a cluster then do nothing and return success
		if (clusterName == None) or (not clusterName.strip()):
			AdminUtilities.infoNotice(AdminUtilities._OK_+msgPrefix+"Ignored - not in a cluster")
			return 1
		#endif
		
		return setClusterMemberAvailable( clusterName, nodeName, serverName, available, last )
	    	
	except:
                typ, val, tb = sys.exc_info()
                return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), "false")       
	#endTry

	return 1 # succeed
#endDef


def setClusterMemberAvailable( clusterName, nodeName, serverName, available="true", last="false" ):

	msgPrefix = "setClusterMemberAvailable("+clusterName+", "+nodeName+", "+serverName+", "+available+", "+last+"): "

	try:
                #--------------------------------------------------------------------
                # Set up globals
                #--------------------------------------------------------------------
                global AdminConfig
		global AdminControl
                
                # check  the required arguments
                if (clusterName == ""):
			return AdminUtilities.fail(msgPrefix+"Invalid clusterName specified: "+clusterName)
		#endif
                if (nodeName == ""):
			return AdminUtilities.fail(msgPrefix+"Invalid nodeName specified: "+nodeName)
		#endif
                if (serverName == ""):
			return AdminUtilities.fail(msgPrefix+"Invalid serverName specified: "+serverName)
		#endif
		if (available == "true"):
			operation = 'setAvailable'
		else:
			operation = 'setUnavailable'
		#endif

		# Get the cluster management object
		clusterObjectName = AdminControl.completeObjectName('name='+clusterName+',*,type=Cluster')
		clusterMgmtObjectName =  mgmt.ObjectName(clusterObjectName)

		# parameters are JVM server name, node name
		params=[serverName, nodeName]
		signature = ['java.lang.String','java.lang.String']

		# NOTE: Commented this out, since it probably doesn't save much...
		# Determine the current state of the cluster member and exit with success if already in target available state
		#memberAvailable = (AdminControl.invoke_jmx(clusterMgmtObjectName, 'getAvailable',  params, signature) == 1)
		#targetStateAvailable = (operation == "setAvailable")
		#if (memberAvailable == targetStateAvailable):
		#	AdminUtilities.infoNotice(AdminUtilities._OK_+msgPrefix+" Server: "+serverName+", Node: "+nodeName+", cluster: "+clusterName+ "already in target state "+operation)
		#	return 1 # succeed
		#endif

		# If we are setting a cluster member unavailable, check if it this is the last cluster member
		# and only do so if 'last' is true
		if (operation == "setUnavailable"):
			if ((countAvailableAndRunningMembers(clusterName) < 2) and (last != "true")):
				return AdminUtilities.fail(msgPrefix+"Last available cluster member could not be set unavailable.")
			#endif
		#endif

		# mark the JVM down
		AdminControl.invoke_jmx(clusterMgmtObjectName, operation, params, signature)

        except:
                typ, val, tb = sys.exc_info()
                return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), "false")       
        #endTry

        AdminUtilities.infoNotice(AdminUtilities._OK_+msgPrefix+"Operation: "+operation+" succeeded for server: "+serverName+" on Node: "+nodeName+" in cluster: "+clusterName)
        return 1  # succeed
#endDef

## Get the cluster member availabilty ##
def getClusterMemberAvailable( clusterName, nodeName, serverName ):

	msgPrefix = "getClusterMemberAvailable("+clusterName+", "+nodeName+", "+serverName+"): "

	try:
                #--------------------------------------------------------------------
                # Set up globals
                #--------------------------------------------------------------------
                global AdminConfig
		global AdminControl
                
                # check  the required arguments
                if (clusterName == ""):
			return AdminUtilities.fail(msgPrefix+"Invalid clusterName specified: "+clusterName)
		#endif
                if (nodeName == ""):
			return AdminUtilities.fail(msgPrefix+"Invalid nodeName specified: "+nodeName)
		#endif
                if (serverName == ""):
			return AdminUtilities.fail(msgPrefix+"Invalid serverName specified: "+serverName)
		#endif

		# Get the cluster management object
		clusterObjectName = AdminControl.completeObjectName('name='+clusterName+',*,type=Cluster')
		clusterMgmtObjectName =  mgmt.ObjectName(clusterObjectName)

		# parameters are JVM server name, node name
		params=[serverName, nodeName]
		signature = ['java.lang.String','java.lang.String']

		# Determine the current state of the cluster member
		memberAvailable = (AdminControl.invoke_jmx(clusterMgmtObjectName, 'getAvailable',  params, signature) == 1)

        except:
                typ, val, tb = sys.exc_info()
                return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), "false")
                
        #endTry

	if (memberAvailable):
		state = "AVAILABLE"
	else:
		state = "UNAVAILABLE"
	#endif
        AdminUtilities.infoNotice(AdminUtilities._OK_+msgPrefix+serverName+" on Node: "+nodeName+" in cluster: "+clusterName+" is "+state)
        return  memberAvailable # succeed
#endDef


## Print cluster information ##
def getClusterInfo( clusterName ):

	msgPrefix = "getClusterInfo("+clusterName+"): "

	try:
                #--------------------------------------------------------------------
                # Set up globals
                #--------------------------------------------------------------------
                global AdminConfig
		global AdminControl
                
                # check  the required arguments
                if (clusterName == ""):
			return AdminUtilities.fail(msgPrefix+"Invalid clusterName specified: "+clusterName)
		#endif

		# Get the cluster management object
		clusterObjectName = AdminControl.completeObjectName('name='+clusterName+',*,type=Cluster')

		clusterInfo = AdminControl.invoke(clusterObjectName,'dumpClusterInfo')

        except:
                typ, val, tb = sys.exc_info()
                return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), "false")
                
        #endTry

        AdminUtilities.infoNotice(AdminUtilities._OK_+msgPrefix+"Operation: dumpClusterInfo succeeded for  cluster: "+clusterName)
        return  clusterInfo # succeed
#endDef


## Count number of cluster members that are available AND running
def countAvailableAndRunningMembers( clusterName ):

	msgPrefix = "countAvailableAndRunning("+clusterName+"): "
	nAvailableAndRunning = 0
	try:
		clusterInfo = getClusterInfo(clusterName)
		lines = clusterInfo.splitlines()

		# Look for "Member Available" == true followed by non null "Member Object Name" 
		# which means the member is running
		for line in lines:
			words = line.split(':', 1)
			if (len(words) == 2):
				key = words[0]
				val = words[1].strip()
				if (key == "Member Available"):
					isAvailable = val
				elif (key == "Member Object Name"):
					if ((isAvailable == "true") and (val != "null")):
						nAvailableAndRunning = nAvailableAndRunning + 1
					#endif
				#endif
			#endif
		#endFor
		print AdminUtilities._OK_+msgPrefix+"Found", nAvailableAndRunning, "members available and running."
		return nAvailableAndRunning
	except:
                typ, val, tb = sys.exc_info()
                return AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), "false")
	#endTry
#endDef

