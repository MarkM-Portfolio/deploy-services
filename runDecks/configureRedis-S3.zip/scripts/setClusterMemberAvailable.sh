#!/bin/bash

# Load the patch utility functions
source ${SCRIPT_HOME}/patch_utils.sh

#
# Mark one or more cluster members up/down on the current node.
#

function usage()
{
    echo "MarkClusterMemberUpDown.sh --available|--unavailable --last|-l --node|-n <nodeName> ALL|<server1> [<server2>...<serverN>]"
    echo "Parameters:"
	echo "  --available|--unavailable	mark server available/unavailable"
	echo "  --last	<true|false>	(optional) take member server down even if it is the last available member in the cluster. Default=true"
	echo "  --node <nodeName>     	(optional) specifies the name of the node for the server. default=local node"
	echo "  ALL		Mark all servers up/down"
	echo "  <serverN>	Server to mark up/down. One of: serverA, serverC, serverS, engage_server, push"
}

function getNodeName()
{
    ps -ef | grep WebSphere | grep nodeagent | awk '{ print $(NF-1) }'
}


echo "$0" "$@"

if [ $# -lt 1 ]; then
    usage
    exit 1
fi

# Process and validate the command line options
available=""
server=""
last="true"

# Get the local node name
nodeName=$(getNodeName)

while [[ $# > 0 ]]; do
    key="$1"
    case $key in
        --available|-a)
           available="true"; targetState="Available"; shift
           ;;
        --unavailable|-u)
           available="false"; targetState="Unavailable"; shift
           ;;
        --last|-l)
           shift; last="$1"; shift
           ;;
        --node|-n)
           shift; nodeName="$1"; shift
           ;;
        *)
	   servers="$@"
	   break 
	   ;;
    esac
done

if [ -z "$available" ]; then
    echo " Error: Missing required option --available|--unavailable."
    usage
    exit 1
fi

if [ -z "$servers" ]; then
    echo " Error: Missing required server name(s)."
    usage
    exit 1
fi

if [ -z "$nodeName" ]; then
    echo " Error: Invalid node name, $nodeName"
    usage
    exit 1
fi

# Save the current directory and cd to $SCRIPT_HOME
PWD=$(pwd)
cd "${SCRIPT_HOME}"

# call the wsadmin python script to execute the requested operation
cmd="${SCRIPT_HOME}/setClusterMemberAvailable.py $available $last $nodeName $servers"
result=$(sudo -u websphere /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/wsadmin.sh -user $username -password $password -lang jython -f ${cmd})
echo "${result}"
if [[ ${result} == *"SUCCESS:"* ]]; then
    echo "Successfully set ($servers) to $targetState"
    cd "${PWD}"
    exit 0
else
    echo "Error: Failed to set ($servers) to $targetState"
    cd "${PWD}"
    exit 1
fi


