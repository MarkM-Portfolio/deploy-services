#!/bin/bash  

# Load the patch utility functions
source ${SCRIPT_HOME}/patch_utils.sh


function usage()
{
    echo "Usage: copyfiles [--dir|-d <directory>] [--backupDir|-b <backupDir>] [--noBackup|-n] [--ignoreErrors|-i]"
    echo "Parameters:"
    echo "  --dir|d <directory>   	The directory containing files/directories to be copied. MUST be specified."
    echo "  --backupDir|-b <backupDir>	(Optional) Location to backup files before copying. If not specified no backup will be done."
    echo "  --noBackup|-n 		(Optional) Location to backup files before copying. Default=false"
    echo "  --ignoreErrors|-i		(Optional) Ignore errors. default=false"
}


# Process and validate the command line options
srcDir=""
ignoreErrors=false
backupDir=""
while [[ $# > 0 ]]; do
    key="$1"
    case $key in
        --dir|-d)
            shift; srcDir="$1"
            ;;
        --ignoreErrors|-i)
            ignoreErrors=true
            ;;
        --backupDir|-b)
            shift; backupDir="$1"
            ;;
        --noBackup|-n)
            backupDir=""
            ;;
        *)
            echo "Error: Unrecognized option."
            usage
            exit 1
            ;;
    esac
    shift
    if [ $? -ne 0 ]; then
        echo "Error: Invalid parameters."
        usage
        exit 1
    fi
done

# Verify that srcDir exists
if [ ! -d "${srcDir}" ]; then
    echo " Error: source directory <${srcDir}> does not exist."
    usage
    exit 1
fi

srcDirname="${srcDir##*/}"

# If this is NOT a rollback operation (no backup performed in this case), and no backup directory 
# has been specified, then use the $PATCH_BACKUP_HOME
if [[ -z "${backupDir}" ]] && [[ "${PATCH_IS_ROLLBACK}" != "true" ]]; then
    backupDir="${PATCH_BACKUP_HOME}/${srcDirname}"
fi
if [ -n "${backupDir}" ]; then
    echo "Original files will be backed up to: ${backupDir}"
else
    echo "Original files will NOT be backed up"
fi

# Validate/set file owner/group setting
if [ -z "$PATCH_FILE_OWNER" ]; then
    PATCH_FILE_OWNER="websphere:websphere"
fi
echo " File ownership will be set to ${PATCH_FILE_OWNER} after copy."

# Validate/set file permissions setting
if [ -z "$PATCH_FILE_PERMISSIONS" ]; then
    PATCH_FILE_PERMISSIONS=644
fi
echo " File permissions will be set to ${PATCH_FILE_PERMISSIONS} after copy."

# Get a list of files in the patch
patchedFilesList="${PATCH_FILES_HOME}/patchfiles.${srcDirname}"
find ${srcDir}/ -name "*" -type f > "${patchedFilesList}"

# Get a list of files to be replaced (absolute paths) RELATIVE to scrDir
backupFilesList="${PATCH_FILES_HOME}/backupfiles.${srcDirname}"
cp "${patchedFilesList}" "${backupFilesList}"
srcDirEsc=$(echo "$srcDir" | sed -e 's/[]\/$*.^|[]/\\&/g')
sed -ri "s/^${srcDirEsc}\//\//g" "${backupFilesList}"

# Strip out the version number from the filenames
if [ -n "$PATCH_REGEX_VERSION" ]; then
    p="s/${PATCH_REGEX_VERSION}/${PATCH_REGEX_REPLACE}/g"
    sed -ri "$p" "${backupFilesList}"
fi

# Create backup directory to save files that are replaced by this patch
if [ -n "${backupDir}" ]; then
    mkdir -p ${backupDir}
    rc=$?; exitOnError $rc "Error: Failed to create backup directory ${backupDir}"
fi

# Verify, backup and replace files to be patched
count=0
while IFS='' read -r filepath || [[ -n "$filepath" ]]; do

    # Verify destination file to be replaced exists and is unique
    verifyExistsUnique "$filepath"

    # Verify patched file exists under ./$srcDir and is unique
    verifyExistsUnique "$srcDir/$filepath"

    # Backup existing file and replace with patched
    patchSrcFile=$(find $srcDir/$filepath)
    replaceFile=$(find $filepath)
    patchDestDir=$(dirname "$replaceFile")
    patchDestFile="$patchDestDir"/${patchSrcFile##*/}
    if [ -n "${backupDir}" ]; then
        echo "Backing up $replaceFile to ${backupDir}/$replaceFile"
        cp --parent -rfv "$replaceFile" ${backupDir}
	rc=$?; exitOnError $rc "Error: Failed to backup $replaceFile"
    fi
    #mv -fv "$replaceFile" "$replaceFile".${PATCH_DATE}
    rm -fv "$replaceFile"
    rc=$?; exitOnError $rc "Error: Failed to remname $replaceFile"
    cp -rfv "$patchSrcFile" "$patchDestFile"
    rc=$?; exitOnError $rc "Error: Failed to copy $patchSrcFile --> $patchDestFile"
    chown "$PATCH_FILE_OWNER" "$patchDestFile"
    rc=$?; exitOnError $rc "Error: Failed to change ownership $PATCH_FILE_OWNER on patched file $patchDestFile"
    chmod "$PATCH_FILE_PERMISSIONS" "$patchDestFile"
    rc=$?; exitOnError $rc "Error: Failed to change permissions to $PATCH_FILE_PERMISSIONS on patched file $patchDestFile"
    ((count++))
   
done < "${backupFilesList}" 

echo "Success: $count files copied"
exit 0









