#!/bin/bash

# Load the patch utility functions
source ${SCRIPT_HOME}/patch_utils.sh

#
# Mark one or more cluster members up/down on the current node.
#

function usage()
{
    echo "getServerName.sh <appName>"
    echo "Parameters:"
    echo "  <appName>	name of installed application"
}

function getNodeName()
{
    ps -ef | grep WebSphere | grep nodeagent | awk '{ print $(NF-1) }'
}


if [ $# -lt 1 ]; then
    #usage
    exit 1
fi

appName="$1"
node_name="$2"
if [ -z "${node_name}" ]; then
    node_name=$(getNodeName)
fi

# Save the current directory and cd to $SCRIPT_HOME
PWD=$(pwd)
cd "${SCRIPT_HOME}"

# call the wsadmin python script to execute the requested operation
cmd="${SCRIPT_HOME}/getServerName.py ${appName} ${node_name}"
result=$(sudo -u websphere /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/wsadmin.sh -user $username -password $password -lang jython -f ${cmd})
#echo "${result}"

serverName=$(echo "${result}" | grep "APPLICATION INSTALLED ON:" | awk '{ print $(NF) }')

echo "${serverName}"
cd "${PWD}"
if [ -z "${serverName}" ]; then
    exit 1
else
    exit 0
fi

