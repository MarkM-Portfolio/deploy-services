import sys
ear_name=sys.argv[1]
ear_app_map = {
    'mobile.ear': 'Mobile',
    'dboard.ear': 'Homepage',
    'communities.ear': 'Communities',
    'wikis.ear': 'Wikis',
    'news.ear': 'News',
    'search.ear': 'Search',
    'help.ear': 'Help',
    'connections.common.ear': 'Common',
    'mobile.admin.ear': 'Mobile Administration',
    'widget.container.ear': 'WidgetContainer',
    'blogs.ear': 'Blogs',
    'connections.proxy.ear': 'ConnectionsProxy',
    'profiles.ear': 'Profiles',
    'forums.ear': 'Forums',
    'oembed.ear': 'URLPreview',
    'lconn.pushnotification.ear': 'PushNotification',
    'oa.ear': 'Activities',
    'files.ear': 'Files',
    'meetings.ear': 'meetings',
    'sanity.ear': 'sanity',
    'st.endpoint.ear': 'st.endpoint',
    'switchbox-getfile.ear': 'switchbox-getfile',
    'forms.ear': 'forms',
    'viewer.ear': 'Viewer',    
    'contacts.ear': 'Contacts',
    'scee.ear': 'AppRegistry',
    'appregui.ear': 'AppRegistryUI',
    'metrics.ui.restapi.ear': 'MetricsUIRestAPISC',
    'metrics.eventcapture.ear': 'MetricsEventCapture'
}

if ear_name in ear_app_map:
    print ear_app_map[ear_name]
else:   
    print ""


