#--------------------------------------------------------------------
# Set global constants
#--------------------------------------------------------------------

import sys
import java
import AdminUtilities 
import javax.management as mgmt

execfile('clusterFuncs.py')

def main():

    msgPrefix="setClusterMemberAvailable.py: "

    # Parse the command options
    if (len(sys.argv) < 4):
	AdminUtilities.fail(msgPrefix+"Insufficient arguments specified.")
	return
    #endif

    available = sys.argv[0]
    last = sys.argv[1]
    nodeName = sys.argv[2]

    try:
	result = 1 # success

	# Determine list of servers by id that are to be set Available/Unavailable
	serverIds = []
	if (sys.argv[3] == 'ALL'):
	    serverIds = listServerIds("APPLICATION_SERVER", nodeName)
	else:
	    # Validate and build a list of unique APPLICATION server ids from remaining args
	    for serverName in sys.argv[3:]:
		sid = AdminConfig.getid("/Node:"+nodeName+"/Server:"+serverName)
		if (sid not in serverIds):
		    # Make sure it's an application server
		    serverType = AdminConfig.showAttribute(sid, "serverType")
		    if (serverType == "APPLICATION_SERVER"):
			serverIds.append(sid)
		    else:
		        return AdminUtilities.fail(msgPrefix+"Invalid server name specified - not an application server: "+serverName+", type="+serverType)
		    #endif
		#endif
	    #endfor
	#endif

	print serverIds

	for sid in serverIds:
	    AdminUtilities.infoNotice(AdminUtilities._OK_+msgPrefix+"Calling: setClusterMemberAvailableById("+sid+", "+available+", "+last+")")
	    result = setClusterMemberAvailableById(sid, available, last)
	    if (result == -1):
		AdminUtilities.fail(msgPrefix+"setClusterMemberAvailableById("+sid+", "+available+", "+last+") returned with error.")
		break;
	    #endif
	#endfor
    except:
        typ, val, tb = sys.exc_info()
        AdminUtilities.fail(msgPrefix+AdminUtilities.getExceptionText(typ, val, tb), "false")
        result = -1 # fail
    #endTry


    # Operation successfully completed
    if (result != -1):
	AdminUtilities.infoNotice("\nSUCCESS: "+msgPrefix+"main() Completed")
    #endif

#endDef

# Allow this file to be used as a module
if __name__ == "__main__":
	# Call the main function
	main()
#endif "__main__"

