Rundeck Patch Automation
------------------------
Name: patch_zip_src
Location: /opt/ll/scripts/ac/rundeck/patch_zip_src/


Overview:
--------
The scripts in this directory can be used to build a "Patch ZIP" file for use with Rundeck to automatically deploy
patches to EAR files, JAR files and other (non-EAR/JAR) files in a previously deployed SC Connections environment.
The "Patch ZIP" file contains these scripts, together with any patched EAR files, JAR files, and other files to be installed
on the target node(s) to be patched. There is also a properties file that may be used to customize the actions performed,
though in most cases the defaults should suffice.

The scripts perform the following actions on each patch target node:

- Set all AC servers to Unavailable state in their respective clusters.
- Disable antivirus.
- (DMGR ONLY) Backup and update <versionStamp> in LotusConnections-config.xml if necessary. 
- (DMGR ONLY)Backup existing EAR files and install patched EAR files (if any provided).
- Backup and replace one or more JAR files (if any provided).
- Backup and replace any other files (if any provided).
- Synchronize the node, if necessary.
- Clear server temp files and restart servers, as necessary.
- (OPTIONAL) Clear JVM and OSGI caches. In this case ALL servers are re-started
- (OPTIONAL) Restart memcached and httpd
- Enable antivirus.
- Set all AC servers to Available state in their respective clusters

Notes:
1. 	By default LCC.xml <versionStamp> is only updated if one or more web resource JAR files are included in the patch.
	An override is available via patch.properties to force/prevent a <versionStamp> update from being performed.
2.	The node is synchronized if LCC.xml <versionStamp> was updated, or if any EAR files where installed.
	An override is available via patch.properties to force/prevent node synchronization from being performed.
3.	The list of servers that are restarted and have temp files deleted is determined as follows:
	. If an application/EAR that runs on a server has been updated, then that server is included
	. If OSGI cache is cleared then all running application servers on the node are included
	. If a web resource JAR file(s) has been updated then the application server running the "Common" application
		is included
	. Any servers specified via the patch.properties/PATCH_RESTART_SERVERS option are included


Rollback:
	A rollback script (rollbackChange) is provided to restore the original the EAR files, JAR files and any other
	files that were updated and restart the affected application server(s).


Applicable Nodes Types:
	AC Deployment Manager
	AC Application Server


The instructions below describe in detail how to 

	- Build a "Patch ZIP" file to install your patch
	- How to Upload your "Patch ZIP" file to Rundeck
	- How to execute the Rundeck "Automated Patching" job to install your patch


How to Build a "Patch ZIP" File:
--------------------------------
1. Copy all files in /opt/ll/scripts/ac/rundeck/patch_zip_src from a deployed AC node that is RUNNING THE 
   ***SAME AC VERSION*** AS THE TARGET PATCH ENVIRONMENT to a clean directory <mypatch_dir>

	> mkdir -p <mypatch_dir>
	> cp -rf /opt/ll/scripts/ac/rundeck/patch_zip_src/* <mypatch_dir>

2. Copy the patched EAR/JAR/other file(s) to <mypatch_dir>/patch_files/ directory, as follows:

	- EAR files --> <mypatch_dir>/patch_files/ear/
	  You can use any path under this directory for your EAR files

	- JAR files --> <mypatch_dir>/patch_files/jar/
	  The relative path under <mypatch_dir>/patch_files/jar/ must be the ABSOLUTE full path to the 
	  location where each patched JAR file is to be copied on the target node

	- Other files --> <mypatch_dir>/patch_files/other/
	  The relative path under <mypatch_dir>/patch_files/other/ must be the ABSOLUTE full path to the 
	  location where each file is to be copied on the target node

	For example:

	> mkdir -p <mypatch_dir>/patch_files
	> cp <my_patched_ear_file> <mypatch_dir>/patch_files/ear/<my_patched_ear_file>
	> cp /<my_patched_jar_path>/<my_patched_jar_filename> <mypatch_dir>/patch_files/jar/<my_patched_jar_path>/<my_patched_jar_filename>
	> cp /<my_patched_other_path>/<my_patched_other_filename> <mypatch_dir>/patch_files/other/<my_patched_other_path>/<my_patched_other_filename>
	
3. Edit the file <mypatch_dir>/patch.properties file to specify optional settings for the patch operation.
   The available options are described in detail in <mypatch_dir>/patch.properties.

4. Create a ZIP file containing all files in <mypatch_dir>:

	> cd <mypatch_dir>
	> zip -r <mypatch_zip> *


How to Upload your "Patch ZIP" file to Rundeck
----------------------------------------------
Upload your "Patch ZIP" file to Rundeck using the patch uploader site at https://rundeck1.swg.usma.ibm.com/patchuploader/

Enter an appropriate name in the "Change Name" section. This is required in the when you execute the Rundeck "Automated Patching" job.


How to execute the Rundeck "Automated Patching" job to install your patch
-------------------------------------------------------------------------
- Open the Rundeck UI at https://rundeck1.swg.usma.ibm.com:4443/
- In the Rundeck UI, select the "JobDevelopment" project
- Navigate to the /PROMOTED/AutoPatching folder and click on the "Automated Patching V2" job
- Enter the setting for the patch execution, for example:
	
	cloudID: BHT5A
	verboseF5Log: False
	ignoreF5HealthCheckFail: False
	changeFile: RTC185076-patch_news_20151120_b.zip
	sourcePath: http://rundeck1.swg.usma.ibm.com/changerepository
	runMode: execute
	ignoreSanityFail: False
	userName: <username for DPUI login>
	dpuiHostName: cloud.swg.usma.ibm.com
	nodeTypes: AC Deployment, AC App 

Note: If the target node(s) have been redeployed since previously running the "Automated Patching V2" job then it you must run the
	/IN_DEVELOPMENT/CHEF/"Clear Chef Node" Job against each node to be patched PRIOR to running the "Automated Patching V2" job.

For more details refer to: https://w3-connections.ibm.com/activities/service/html/mainpage#activitypage,1e61f5ef-14b9-471a-a27d-cf8cf50e8ffd





