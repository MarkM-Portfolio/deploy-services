#!/bin/bash

set -o errexit
set -o pipefail

REDIS_HOST=""
REDIS_PORT=""
REDIS_SECRET=""
USER="websphere"
GROUP="websphere"


logErr() {
        logIt "ERRO: " "$@"
}

logInfo() {
        logIt "INFO: " "$@"
}

logIt() {
        echo "$@"
}

usage() {
        logIt ""
        logIt "Usage: ./configureRedisJSON.sh [OPTION]"
        logIt "This script will configure IBM Connections for communicating Redis traffic to OrientMe, using a JSON file to configure the Highway"
        logIt ""
        logIt "Prereqs"
        logIt " - This script must be run as a user with chown and cp privlidges.  e.g. root"
        logIt " - This script must be run on the Deployment Manager machine itself"
        logIt ""
        logIt "Options are:"
        logIt "-se   | --servername             Server Hostname/IPAddress : The IP/Hostname of the Orient Me server. Required."
        logIt "-po   | --port                   The external port that Redis is running on within CFC. Required."
        logIt "-pw   | --password               Password for Redis Secret.  Must match value in Kubernetes secret.  Required."
        logIt ""
        logIt "-us   | --user                   The Linux user to own the file 00000000-0000-0000-0000-000000000000.json.  Default is websphere.  Optional"
        logIt "-gr   | --group                  The Linux Group to own the file 00000000-0000-0000-0000-000000000000.json.  Default is websphere.  Optional"

        logIt ""
        logIt "sample usage (set Redis Host, Redis Port and Redis Password) : ./configureRedisJSON.sh -se <Hostname/IPAddress> -po <Redis Port> -pw <Redis Secret>"
        logIt ""
        logIt "sample usage (set Redis Host, Redis Port and Redis Password while setting the user and group that will own the json file) : ./configureRedisJSON.sh -se <Hostname/IPAddress> -po <Redis Port> -pw <Redis Secret> -us wasuser -gr wasuser"
        logIt ""

        exit 1
}

configureRedisJSON() {


        FILE=00000000-0000-0000-0000-000000000000.json
        UPDATEDIR="/mnt/nas/runtime/LotusConnections/Data/configuration/update"
	
	# check for existance of supporting JSON File
        if [ -f $FILE ]; then
                logIt "File $FILE exists."
        else
                logErr "File $FILE does not exist. Exiting."
                exit 1
        fi

        # replace values in the file with values from user input

        sed -i 's/REDIS_HOST/'$REDIS_HOST'/g' $FILE

        sed -i 's/REDIS_PORT/'$REDIS_PORT'/g' $FILE

        sed -i 's/REDIS_SECRET/'$REDIS_SECRET'/g' $FILE

        # change ownership of the file to specified user and group.
	if [ ${changeOwn} = true ]; then
 	       chown ${USER}:${GROUP} $FILE
	fi

        # Check if target directory exists
        if [ ! -d "$UPDATEDIR" ]; then
           logErr "Target directory $UPDATEDIR does not exist."
           exit 1
        fi

        # Copy the file to  /mnt/nas/runtime/LotusConnections/Data/configuration/update
        if [ ${copyFile} = true ]; then
	        cp -av $FILE $UPDATEDIR
	fi

        if [ -f "$UPDATEDIR/$FILE" ]; then
                logIt "File $FILE exists $UPDATEDIR."
        else
                logErr "File $FILE does not exist on $UPDATEDIR."
                exit 1
        fi

        logIt ""
        logIt "=========================================================="
        logIt "Next Steps"
        logIt ""
        logIt "Restart the following Application Servers : Common News"
        logIt ""
        logIt "On Production Systems "
        logIt "1. Take each node out of rotation and restart Common & News"
        logIt "2. Put node back in rotation"
        logIt "3. Do the next one, until Common & News on all nodes have been restarted."
        logIt "=========================================================="


}

copyFile=false
changeOwn=false

while [[ $# -gt 0 ]]
do
        key="$1"

        case $key in
                -us|--user)
                        USER="$2"
                        shift
                        ;;
                -gr|--group)
                        GROUP="$2"
                        shift
                        ;;
                -se|--servername)
                        REDIS_HOST="$2"
                        shift
                        ;;
                -po|--port)
                        REDIS_PORT="$2"
                        shift
                        ;;
                -pw|--password)
                        REDIS_SECRET="$2"
                        shift
                        ;;
                -cp|--copy)			
			copyFile=true			
                        ;; 
                -ch|--changeOwn)
			changeOwn=true
			;;
                *)
                        usage
                        ;;
        esac
        shift
done


if [ "${REDIS_HOST}" = "" -o "${REDIS_PORT}" = "" -o "${REDIS_SECRET}" = "" ]; then
        logErr "Missing Hostname, Redis Port, or Redis Password definitions"

        logErr "REDIS_HOST = ${REDIS_HOST}"
        logErr "REDIS_PORT = ${REDIS_PORT}"
        logErr "REDIS_SECRET = ${REDIS_SECRET}"


        logErr ""

        usage

        exit 5
fi


(
        configureRedisJSON

) 2>&1 | tee -a /var/log/configureRedisJSON.log


exit 0
