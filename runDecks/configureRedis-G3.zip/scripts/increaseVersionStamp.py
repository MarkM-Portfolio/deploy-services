import os
import os.path
import sys
import logging
import time,sys,subprocess,socket,fileinput,re
import shutil

from xml.dom import minidom
from xml.dom.ext import PrettyPrint
from StringIO import StringIO
from sys import argv

def _init_log():  

    log_dir = '/tmp/'
    log_path = log_dir + os.sep + 'versionstamppatch.log'
  
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s %(levelname)s %(message)s',
                        filename=log_path,
                        filemode='w')

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)

def toprettyxml(node, encoding='UTF-8'):
    tmpStream = StringIO()
    PrettyPrint(node, stream=tmpStream, encoding=encoding)
    return tmpStream.getvalue()    

def update_version_stamp(lotusconnectionsxml, outputxml=''):
    
    
    try:
        doc = minidom.parse(lotusconnectionsxml)

        for element in doc.getElementsByTagName('versionStamp'):
            existingValue = element.getAttribute('value')
            logStr = 'Existing versionStamp : %s' % existingValue
            logging.info(logStr)
            d,t=existingValue.split(".")
            year = d[:4]
            month = d[4:6]
            day = d[6:8]
            hour = t[:2]
            minute = t[2:4]
            second = t[4:6]
            second=str(int(second)+1)
            if (int(second) < 10):  
                second = "0" + str(int(second))
            elif (int(second) > 59):
                second = "00"
                minute = str(int(minute) + 1)
            if (int(minute) < 10):
                minute = "0" + str(int(minute))
            elif (int(minute) > 59):
                minute = "00"
                hour = str(int(hour) + 1)
            if (int(hour) < 10):
                hour = "0" + str(int(hour))
            elif (int(hour) > 23):
                hour = "00"
                day = str(int(day) + 1)
            if (int(day) < 10):
                day = "0" + str(int(day))
            elif (int(day) > 28):
                day = "01"
                month = str(int(month) + 1)
            if (int(month) < 10):
                month = "0" + str(int(month))
            elif (int(month) > 12):
                month = "01"
                year = str(int(year) + 1)

            newstr=year + month + day + "." + hour + minute + second
            element.setAttribute('value', newstr)
            logStr = 'New versionStamp : %s' % newstr
            logging.info(logStr)
            f = open(lotusconnectionsxml,'w')
            f.write(toprettyxml(doc))
            f.close()
            logging.info('File %s was saved with a new versionStamp value' % lotusconnectionsxml)
    except:
        logging.error('Error occured!')
        raise


if __name__ == '__main__' :

    _init_log()

    logStr = 'Invoking script: %s' % argv[0]
    logging.info(logStr)
    if (len(argv) < 2):
        logging.info('Usage: %s <LCC.xml> <new version stamp>' % argv[0])
        sys.exit(-1)
    else:
        lcc_config = argv[1] # ex: /opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config/cells/ocs_cell/LotusConnections-config/LotusConnections-config.xml
#        versionStamp = argv[2] # ex: 20130904.163745

        update_version_stamp(lcc_config)

