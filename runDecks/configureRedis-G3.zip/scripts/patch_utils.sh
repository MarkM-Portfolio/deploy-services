#!/bin/bash

# Get the login credentials for wsadmin
source /opt/ll/lib/registry/registryLib.sh
source /opt/ll/lib/apache/zookeeper/zooKeeperLib.sh
getSetting MiddlewareWebSphere admin_username
username=$REGISTRY_DATA
getSetting MiddlewareWebSphere admin_password
password=$REGISTRY_DATA


# Print the local node name
# Note: Node agent must be running
function getNodeName()
{
    ps -ef | grep WebSphere | grep nodeagent | awk '{ print $(NF-1) }'
}

# Print a list of the running application servers on this WAS node,removing nodeAgent from the list of JVM restarts
function getRunningAppServers()
{
    nodeName=$(getNodeName)
    appServers=$(ps -ef | grep "/opt/IBM/WebSphere/AppServer/java" | grep ${nodeName} | awk '{ print $(NF) }')
    appServersArr=( ${appServers} )
    nodeAgent=nodeagent
    appServersArr=("${appServersArr[@]/$nodeAgent}")
    echo ${appServersArr[@]}
}

# Get patch from properties file
source patch.properties


function getServerStatus() {
    local serverName=$1
    local statusVarName="${serverName}_status"
    local serverStatus=$(service was.$serverName status)
    eval $statusVarName="'${serverStatus}'"
}

function deleteServerTempFiles() {
    local serverName=$1

    # EngageServer temp directory is not the same as the server name...fix it up, if necessary.
    if [[ "${serverName}" == "engageServer" ]]; then
        serverName="engage_server"
    fi

    echo "Deleting $serverName temp files..."
    rm -rf /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/temp/$(getNodeName)/$serverName/Common
}

function getNodeAgentStatus() {
	nodeagent_status=$(/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/serverStatus.sh nodeagent -username $username -password $password)
}

function syncNode() {
    echo "Synchronizing node..."
    sync_result=$(sudo -u websphere /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/wsadmin.sh -user $username -password $password -lang jython -javaoption "-Djython.package.path=/opt/IBM/WebSphere/AppServer/plugins/com.ibm.ws.wlm.jar" -c "execfile(\"/opt/ll/scripts/ac/syncNode.py\")")

    if [[ "${sync_result}" == *"node is synchronized"* ]]
    then
	current_timestamp=$(date)
	echo "Node synchronized:  $current_timestamp"
    else 
	echo $sync_result
        echo "Error: Node failed to sync"
	exit 1
    fi
}

function fixServerName()
{
    # Fixup engageServer name
    local serverName=$1
    if [[ "${serverName}" == "engage_server" ]]; then
        serverName="engageServer"
    fi
    echo ${serverName}
}

function startServer() {
    local serverName=$(fixServerName $1)
    echo "Starting server $serverName"
    #/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/startServer.sh $serverName &
    sudo service was.$serverName start
}

function stopServer() {
    local serverName=$(fixServerName $1)
    echo "Stopping server $serverName"
    #/opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/stopServer.sh ${serverName} -username $username -password $password &
    sudo service was.$serverName stop
}

function restartServer() {
    local serverName=$(fixServerName $1)
    echo "Restarting server $serverName"
    sudo service was.$serverName restart
}


function verifyServerStopped() {
    local serverName=$(fixServerName $1)
    local maxWait="${PATCH_SERVER_RESTART_MAX_WAIT}"

    # Default to 30 max wait if not specified
    if [ -z "${maxWait}" ]; then
        maxWait=30
    fi

    #
    # Poll for status, making sure to wait atleast some minimum interval (5 seconds) and also
    # not to wait unnecessarily
    #
    local serverStatus=
    local waitInterval=5
    local remainingWait="${maxWait}"
    if [[ "${remainingWait}" -lt "${waitInterval}" ]]; then
	remainingWait="${waitInterval}"
    fi
    local isStopped="false"

    while [[ "${isStopped}" == "false" && "${remainingWait}" -ge 0 ]]; do
	serverStatus=$(sudo service was.$serverName status)
	if [[ $serverStatus == *"is not running"* ]] || [[ $serverStatus == *"stopped"* ]]; then
	    isStopped="true"
	else
	    sleep "${waitInterval}"
	    (( remainingWait-="${waitInterval}" ))
	fi
    done

    # Print results
    if [[ "${isStopped}" == "true" ]]; then
	echo "$serverName stopped"
    else
	echo $serverStatus
	echo "Error: Failed to stop $serverName"
	exit 1
    fi
}

function verifyServerStarted() {
    local serverName=$(fixServerName $1)
    local maxWait="${PATCH_SERVER_RESTART_MAX_WAIT}"

    # Default to 30 max wait if not specified
    if [ -z "${maxWait}" ]; then
        maxWait=30
    fi

    #
    # Poll for status, making sure to wait atleast some minimum interval (5 seconds) and also
    # not to wait unnecessarily
    #
    local serverStatus=
    local waitInterval=5
    local remainingWait="${maxWait}"
    if [[ "${remainingWait}" -lt "${waitInterval}" ]]; then
	remainingWait="${waitInterval}"
    fi
    local isStarted="false"

    while [[ "${isStarted}" == "false" && "${remainingWait}" -ge 0 ]]; do
	serverStatus=$(sudo service was.$serverName status)
	if [[ $serverStatus == *"is running"* ]]; then
	    isStarted="true"
	else
	    sleep "${waitInterval}"
	    (( remainingWait-="${waitInterval}" ))
	fi
    done

    # Print results
    if [[ "${isStarted}" == "true" ]]; then
	echo "$serverName started"
    else
	echo $serverStatus
	echo "Error: Failed to start $serverName"
	exit 1
    fi
}

function restartMemcached() {
    echo "Restarting memcached"
    sudo /etc/init.d/memcached restart
}

function restartHttpd() {
    echo "Restarting httpd"
    sudo service httpd restart
}

function verifyExistsUnique() {
    local filepath="$1"

    num_files=$(find $filepath | wc -l)
    if [ "${num_files}" -ne 1 ]; then
	if [ "${num_files}" -eq 0 ]; then
            echo "Error: No such file $filepath"
	else
	    echo "Error: Multiple files matching $filepath exist."
	fi
        exit 1
    fi
}

function exitOnError() {
    local resultCode=$1
    local errMessage=$2

    if [ "$resultCode" -ne "0" ]; then
        echo $errMessage
	if [ "$ignoreErrors" == "false" ]; then
	    exit $resultCode
	fi
    fi
}


