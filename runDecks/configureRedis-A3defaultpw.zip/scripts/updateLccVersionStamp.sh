#!/bin/bash

# Check that LotusConnections-config.xml exists
lcc_path="/opt/IBM/WebSphere/AppServer/profiles/Dmgr01/config/cells/ocs_cell/LotusConnections-config/LotusConnections-config.xml"
if [ ! -f "${lcc_path}" ]; then
    echo "Error: LotusConnections-config.xml not found at ${lcc_path}"
    exit 1
fi

# Backup the current LotusConnections-config.xml
mkdir -p "${PATCH_BACKUP_HOME}"
cp -f "${lcc_path}" "${PATCH_BACKUP_HOME}/${lcc_path##*/}.${PATCH_DATE}"

# Print the current versionStamp
versionStamp=$(grep -i versionStamp "${lcc_path}")
echo "Initial LCC.xml versionStamp: ${versionStamp}"

# Increment the versionStamp
python ${SCRIPT_HOME}/increaseVersionStamp.py "${lcc_path}"
rc=$?
if [ "$rc" -ne "0" ]; then
    echo "Error: Unable to update <versionStamp> in ${lcc_path}"
    exit 1
fi

# Print the updated versionStamp
versionStamp=$(grep -i versionStamp "${lcc_path}")
echo "Updated LCC.xml versionStamp: ${versionStamp}"
exit 0
