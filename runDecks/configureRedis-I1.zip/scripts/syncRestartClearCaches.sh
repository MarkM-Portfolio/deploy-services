#!/bin/bash 

# Load the patch utility functions
source ${SCRIPT_HOME}/patch_utils.sh


function getPatchEarServerList {

    #
    # Get a list of EAR files in the patch in order to determine which server(s) need to be restarted.
    # If this is a ROLLBACK on a non-DMGR node, then we can't tell what EARs have been rolled back by
    # looking in the <patch>/backup/ear location (it won't exist) so be conservative, and assume that all
    # EARs in the patch were rolled back on DMGR, and restart server(s) based on that assumption.
    #
    earsDir="${PATCH_EARS_DIR}"
    if [[ "${PATCH_IS_ROLLBACK}" == "true" && "${IS_DMGR}" -eq 0 ]]; then
	earsDir="${PATCH_HOME}"/patch_files/ear
    fi

    patchedEarRestartList="${PATCH_FILES_HOME}/patched_ears_restart.out"
    touch "${patchedEarRestartList}"
    if [ -d "${earsDir}" ]; then
        find "${earsDir}"/ -name "*" -type f > "${patchedEarRestartList}"
    fi

    count=0
    while IFS='' read -r ear_path || [[ -n "$ear_path" ]]; do

        ear_name=${ear_path##*/}

        # Get application name
        app_name=$(python ${SCRIPT_HOME}/getAppName.py ${ear_name})
        if [ -z "${app_name}" ]; then
            echo "Error: ${ear_name} not a valid EAR name"
            exit 1
        fi

        server_name=$(${SCRIPT_HOME}/getServerName.sh ${app_name})
        if [ -z "${server_name}" ]; then
            echo "Error: App name ${app_name} not valid"
            exit 1
        fi

        serverRestartEarPatchList+=("${server_name}")
        ((count++))
   
    done < "${patchedEarRestartList}"
}


#
# Determine which servers (if any) have to be restarted and have temp files deleted.
#

# Those servers that need to be restarted due to EAR patching
serverRestartEarPatchList=()
getPatchEarServerList

# Those servers that need to be restarted due to clearing JVM/OSGI cache
serverRestartList=()
if [[ "${PATCH_CLEAR_JVM_OSGI_CACHE}" == "true" ]]; then
    # Restart all running servers
    serverRestartOsgi=$(getRunningAppServers)
    echo "The following servers will be restarted due to clearing OSGI cache: ${serverRestartOsgi} "
    serverRestartList=( ${serverRestartOsgi} )
fi

# If any web resource JARs have been patched then make sure to restart serverS/Common
if [ "${IS_PATCH_WR_JAR}" -gt 0 ]; then
    # Restart server running "Common" application
    serverRestartWebResource=$(${SCRIPT_HOME}/getServerName.sh "Common")
    echo "The following server will be restarted due to web resource update: ${serverRestartWebResource}"
    serverRestartList+=(${serverRestartWebResource})
fi

# Combine the list of servers to be restarted due to EAR patching, web resource patch, JVM/OSGI cache clear and those
# specifed by the user via patch.properties.
IFS=', ' read -a serverRestartUserSpecifiedList <<< "${PATCH_RESTART_SERVERS}"
serverRestartList=( "${serverRestartList[@]}" "${serverRestartEarPatchList[@]}" "${serverRestartUserSpecifiedList[@]}" )

# Get rid of duplicates from the server restart list
if [ -n "${serverRestartList}" ]; then
    eval serverRestartList=($(printf "%q\n" "${serverRestartList[@]}" | sort -u))
fi

echo "The following servers will be re-started: ${serverRestartList[@]}"

#
# SYNCHRONIZE the node if there was an EAR or web resource JAR file patch
#
if [[ ( "${PATCH_FORCE_SYNC_NODE}" == "ALWAYS" ) 
	|| (( "${IS_PATCH_EAR}" -gt 0 || "${IS_PATCH_WR_JAR}" -gt 0 ) 
			&& ( "${PATCH_FORCE_SYNC_NODE}" != "NEVER" )) ]]; then
    syncNode
fi

#
# Stop servers
#
for server in ${serverRestartList[@]}; do
    stopServer "${server}"
done

wait;

for server in ${serverRestartList[@]}; do
    verifyServerStopped "${server}"
done

#
# Delete temp/servers/Common directory
#
for server in ${serverRestartList[@]}; do
    deleteServerTempFiles "${server}"
done

#
# Clear JVM and OSGI cache
#
if [[ "${PATCH_CLEAR_JVM_OSGI_CACHE}" == "true" ]]; then
    # Stop the nodeAgent
    echo "Stopping nodeAgent..."
    stopServer nodeAgent
    wait;
    verifyServerStopped nodeAgent

    echo "Clearing JVM and OSGI cache..."
    sudo -u websphere /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/osgiCfgInit.sh
    sudo -u websphere /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/bin/clearClassCache.sh

    # Start the node agent
    echo "Starting nodeAgent..."
    startServer nodeAgent
    wait;
    verifyServerStarted nodeAgent

    rm -rf /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/logs/*/*.pid
fi

#
# Restart memcached and httpd if specified in patch.properties
#
if [[ "${PATCH_FORCE_MEMCACHED_RESTART}" == "true" ]]; then
    restartMemcached
fi

if [[ "${PATCH_FORCE_HTTPD_RESTART}" == "true" ]]; then
    restartHttpd
fi

#
# Start servers
#
echo "Starting servers..."
for server in ${serverRestartList[@]}; do
    startServer "${server}"
done

wait;

echo "Verify servers started..."
for server in ${serverRestartList[@]}; do
    verifyServerStarted "${server}"
done

echo "Servers started."

# Success
exit 0
