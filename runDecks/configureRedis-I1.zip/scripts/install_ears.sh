#!/bin/bash  

# Load the patch utility functions
source ${SCRIPT_HOME}/patch_utils.sh


function usage()
{
    echo "Usage: install_ears [--dir|-d <directory>] [--backupDir|-b <backupDir>] [--ignoreErrors|-i]"
    echo "Parameters:"
    echo "  directory   The directory containing EAR files to be installed. MUST be specified."
    echo "  backupDir   (Optional) Location to backup original EAR files before installing patched EARs"
    echo "  -i          (Optional) Ignore errors (default-false)"
}


# Process and validate the command line options
srcDir=""
ignoreErrors=false
backupDir=""
while [[ $# > 0 ]]; do
    key="$1"
    case $key in
        --dir|-d)
            shift; srcDir="$1"
            ;;
        --ignoreErrors|-i)
            ignoreErrors=true
            ;;
        --backup|-b)
            shift; backupDir="$1"
            ;;
        *)
            echo "Error: Unrecognized option."
            usage
            exit 1
            ;;
    esac
    shift
    if [ $? -ne 0 ]; then
        echo "Error: Invalid parameters."
        usage
        exit 1
    fi
done

# Verify that srcDir exists
if [ ! -d "${srcDir}" ]; then
    echo " Error: source directory <${srcDir}> does not exist."
    usage
    exit 1
fi

# If this is not a rollback operation (no backup performed in this case), and no backup directory 
# has been specified, then use the $PATCH_BACKUP_HOME
if [[ -z "${backupDir}" ]] && [[ "${PATCH_IS_ROLLBACK}" != "true" ]]; then
    backupDir="${PATCH_BACKUP_HOME}/${srcDir##*/}"
    echo "Original files will be backed up to: ${backupDir}"
fi

# Create backup directory to save original EAR files
if [ -n "${backupDir}" ]; then
    mkdir -p ${backupDir}
fi

# Get a list of EAR files in the patch
find ${srcDir}/ -name "*" -type f > ${PATCH_FILES_HOME}/patched_ears.out

# Verify, backup and and install EAR files to be patched
count=0
echo "Installing patched EAR files..."
while IFS='' read -r ear_path || [[ -n "$ear_path" ]]; do

    ear_name=${ear_path##*/}

    # Get application name
    app_name=$(python ${SCRIPT_HOME}/getAppName.py ${ear_name})
    if [ -z "${app_name}" ]; then
        echo "Error: ${ear_name} not a valid EAR name"
        exit 1
    else
        echo "Found: ${app_name}"
    fi

    # Check for existence of this EAR on target system, for backup
    echo "Checking for existence of ${ear_name}..."
    ear_exists=$(find /opt/ll/apps/ -name $ear_name | wc -l)

    if [ "${ear_exists}" -eq 1 ]; then
        orig_ear_path=$(find /opt/ll/apps/ -name $ear_name)
    fi
	
	#check media folder for metrics ears
	if [ "${ear_exists}" -ne 1 ]; then
	    ear_exists=$(find /opt/ll/media/ -name $ear_name | wc -l)
		
		if [ "${ear_exists}" -eq 1 ]; then
			orig_ear_path=$(find /opt/ll/media/ -name $ear_name)
		fi
	fi
	
    # Need to look in different location for contacts EAR
    if [ "${ear_exists}" -ne 1 ]; then
        ear_exists=$(find /tmp/sccontactsapp/xkit/installableApps/ -name $ear_name | wc -l)
        orig_ear_path=$(find /tmp/sccontactsapp/xkit/installableApps/ -name $ear_name)
    fi

    # Exit if no existing EAR found
    if [ "${ear_exists}" -ne 1 ]; then
        echo "Error: ${ear_name} not found under /opt/ll/apps/, /opt/ll/media/, or /tmp/sccontactsapp/xkit/installableApps/"
        exit 1
    fi
    echo "Found existing EAR at ${orig_ear_path}"

    # Backup the target EAR
    if [ -n "${backupDir}" ]; then
	echo "Backing up original EAR ${orig_ear_path} to ${backupDir}"
	cp ${orig_ear_path} ${backupDir}
	rc=$?; exitOnError $rc "Error: Failed to backup ${orig_ear_path}"
    fi

    # Deploy patched EAR
    echo "Deploying patched EAR: ${ear_name}"
    cmd="\$AdminApp update ${app_name} app {-operation update -contents ${ear_path} };\$AdminConfig save"
    echo $cmd

    install_result=$(sudo -u websphere /opt/IBM/WebSphere/AppServer/profiles/Dmgr01/bin/wsadmin.sh -c "${cmd}")
    if [[ $install_result == *"installed successfully"* ]]; then	
	echo "Installation of ${ear_name} successful, copying patched EAR ${ear_path} to ${orig_ear_path}...)"
	# Rename the original EAR and copy the patched EAR into the standard EAR file location on target node
	mv ${orig_ear_path} ${orig_ear_path}.${PATCH_DATE}
	cp $ear_path ${orig_ear_path}
    else	
	echo $install_result
	echo "Installation of ${ear_name} failed, invoke roll-back script"
	exit 1
    fi

    ((count++))
   
done < ${PATCH_FILES_HOME}/patched_ears.out 


echo "Success: $count EAR files installed"
exit 0









